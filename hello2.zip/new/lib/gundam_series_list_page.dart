import 'package:flutter/material.dart';
import 'gundam_series_card.dart';
import 'gundam_series_detail_page.dart';

class GundamSeriesListPage extends StatelessWidget {
  final List<Map<String, String>> gundamSeries = [
    {
      "title": "기동전사 건담",
      "image": "image/first_gundam.jpg",
      "description": "우주세기 0079. 인류가 과다하게 늘어난 인구를 우주로 이주시킨 지도 이미 반세기.\n"
          "지구에서 가장 먼 우주 도시 사이드 3는 지온 공국이라 자칭하며 지구연방정부에 대항하여 독립전쟁을 시작하였다.\n"
          " 한 달 남짓한 싸움에서 지온 공국과 연방군은 총 인구의 절반을 죽음으로 내몰았고, 연방군이 열세에 놓인 채로 전쟁은 교착 상태에 빠진다.\n"
          "\n"
          "사이드 7의 소년 아무로 레이는 지온군의 기습을 계기로 우연히 연방군의 신형 모빌슈트 건담에 탑승해 조종사가 된다.\n"
          " 전화에서 살아남기 위해, 전함 화이트 베이스로 소년 소녀들과 함께 군인으로서의 싸움을 강요당해 가는 가운데, 이윽고 “뉴타입”으로서 각성한다.",
      "video": "image/first_gundam.mp4"
    },
    {
      "title": "Mobile Suit Zeta Gundam",
      "image": "image/z_gundam.jpg",
      "description": "A direct sequel to the original series, introducing new mobile suits and characters."
    },
    {
      "title": "Mobile Suit Gundam Wing",
      "image": "assets/images/gundam_wing.jpg",
      "description": "A popular alternate universe series featuring the Wing Gundam and its pilots."
    },
    {
      "title": "Mobile Suit Gundam Unicorn",
      "image": "assets/images/gundam_unicorn.jpg",
      "description": "A modern entry in the Universal Century timeline with advanced animation and storytelling."
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Gundam Series Showcase'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: GridView.builder(
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            childAspectRatio: 2 / 3,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
          ),
          itemCount: gundamSeries.length,
          itemBuilder: (context, index) {
            return GundamSeriesCard(series: gundamSeries[index]);
          },
        ),
      ),
    );
  }
}
